require "application_controller" # DON'T DO THIS.


=beginrequire "test_helper"

class ArticlesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
=end